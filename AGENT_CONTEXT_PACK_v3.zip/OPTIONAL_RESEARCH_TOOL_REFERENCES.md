# Optional Research Tool References

This is an **optional reference catalog**, not part of the mandatory universal agent instructions. Consult it only when a task genuinely involves reverse engineering, .NET assembly analysis, Unity IL2CPP, or game-modding workflows. For ordinary coding, CI, build, and test tasks, ignore it unless the repository gives a concrete reason to use one of these tools.

Before adoption, inspect the current README, maintenance activity, prerequisites, security model, integration effort, and license. A saved repository is not automatically a dependency, and listed tools do not replace compiling/testing the actual target. Only inspect binaries and software that you are authorized to analyze. Check licenses before copying code or assets.

## General application / .NET analysis

### REA — Reverse Engineer Anything
https://github.com/morluto/rea

Potentially useful when a project must investigate a reference application across different formats, including native binaries, JavaScript/Electron, .NET assemblies, or websites. The project emphasizes evidence and limitations. Verify its current requirements and maturity before relying on results. Visual evidence is still needed for appearance; REA is not a substitute for screenshots or UI review.

### ILSpy
https://github.com/icsharpcode/ILSpy

A .NET assembly browser and decompiler. Useful for authorized inspection of compiled .NET programs, types, methods, and resources. Decompiled output may not match original source exactly; validate findings through observable behavior and tests.

## Native-binary analysis

### IDA MCP
https://github.com/HexRaysSA/ida-mcp

Potential MCP interface for automating IDA analysis. Only relevant when a native-binary investigation is necessary and the required IDA installation/license and target access are available.

### Ghidra MCP
https://github.com/bethington/ghidra-mcp

Potential automation interface for Ghidra workflows. Relevant for native reverse engineering, not a prerequisite for normal C#, Qt, or CMake builds.

## Unity IL2CPP

### Cpp2IL
https://github.com/SamboyCoding/Cpp2IL

Specialized for Unity IL2CPP analysis/reconstruction. Do not treat it as a general-purpose .NET decompiler, GUI tool, or porting framework. Check current stability and compatibility first.

## Game-modding workflows

### Universal Modder
https://github.com/rehan-remade/universal-modder

Potentially relevant for AI-assisted game-modding workflows, especially when the actual product involves modifying or testing games.

### AI Game Modding Guides
https://github.com/trevaintdead/ai-game-modding-guides

Guides/templates for agent-led game-modding work. Useful when the application’s task actually matches that domain; not a general CI/build service.

## Specialized PS5 executable interoperability

### PortPS5
https://github.com/ymatrix1/PortPS5

Specialized executable/binary porting work for PS5. Not a generic desktop or C# porting reference.

### AnyPS5
https://github.com/boykopovar/AnyPS5

Specialized PS5 executable relinking/interoperability work. Not a universal C# logic/UI framework.

## Selection rule

Pick the smallest toolset that closes a demonstrated evidence gap. For example:

- A compiled .NET desktop reference may justify examining it with ILSpy.
- An unavailable native application may justify IDA/Ghidra research if the user is authorized and has the appropriate tools.
- A Unity IL2CPP target may justify investigating Cpp2IL.
- A normal repository with working source and CI generally needs no reverse-engineering tools at all.

Do not install all listed tools, wire them into every agent session, or copy implementation code without verifying need, access rights, compatibility, and licensing.
