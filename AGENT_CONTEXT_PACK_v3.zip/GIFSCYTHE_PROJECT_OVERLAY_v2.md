# Gifscythe — Project-Specific Context Overlay

**Repository:** https://github.com/freeforall1932-design/gifscythe  
**Review snapshot:** 2026-10-12  
**Use with:** `UNIVERSAL_AGENT_CONTEXT_v2.md`  
**Scope:** This file contains Gifscythe-specific facts and next steps. The universal file defines the reusable engineering method. Recheck the current branch and latest CI state before treating any item below as current.

## 1. Working in Arena

The repository is already connected to Arena Agent Mode. Continue there; a separate AI agent is optional. Use GitHub Actions for a build target that requires Qt/CMake or a Windows SDK missing from Arena. Do not add another plugin simply because Arena cannot locally compile that target.

## 2. What was found in the inspected repository

The following was observed during the 2026-10-12 review; verify it against the current repository before changes:

- `.github/workflows/build.yml` already contains Linux and Windows build/test lanes, a portability lane, a C# spike lane, docs/parity gates, and artifact upload.
- `docs/ci/build.yml.proposed` was observed to be a byte-identical mirror of the live workflow. The project documents a parity check, so edit both copies together and verify parity after a change.
- Linux builds the native engine/CLI and Qt GUI using the repository’s build entry points and Qt-related packages, then executes configured tests and packaging assertions.
- Windows provisions Qt 6.7.3 with MinGW, builds with CMake/Ninja, runs the GUI through the supported offscreen harness, deploys dependencies, checks a portable-package manifest, and uploads artifacts.
- Native Qt-free checks can start with `cd working_code/gifscythe && ./build.sh`.
- `./build.sh --all` requests the full GUI build when the compatible Qt toolchain is available.
- `working_code/gifscythe/scripts/build_qt6_local.sh` exists as a local fallback to build a Qt 6.8.3 environment. It is not required for every code change. Its opening usage example appeared to mention a stale build path, so follow the commands the script actually prints at completion rather than blindly copying the header example.

Sources to inspect:
- [Workflow](https://github.com/freeforall1932-design/gifscythe/blob/main/.github/workflows/build.yml)
- [Workflow mirror](https://github.com/freeforall1932-design/gifscythe/blob/main/docs/ci/build.yml.proposed)
- [CI documentation](https://github.com/freeforall1932-design/gifscythe/blob/main/docs/ci/README.md)
- [Native build script](https://github.com/freeforall1932-design/gifscythe/blob/main/working_code/gifscythe/build.sh)
- [Local Qt fallback](https://github.com/freeforall1932-design/gifscythe/blob/main/working_code/gifscythe/scripts/build_qt6_local.sh)

## 3. Priorities to verify and handle in order

### P0 — Validate current GitHub Actions compatibility

The reviewed workflow used these v4 actions, whose action metadata specified the Node 20 runtime:

- `actions/checkout@v4`
- `actions/setup-dotnet@v4`
- `actions/upload-artifact@v4`
- `actions/download-artifact@v4`

GitHub announced Node 20 retirement in GitHub Actions on 2026-09-23. Recheck the actual current workflow, any other action dependencies, current official releases, and compatibility before updating. Treat version tags researched on 2026-10-12 as candidates, not automatic replacements.

Update `.github/workflows/build.yml` and `docs/ci/build.yml.proposed` together, preserve byte equality, run the repository’s YAML/docs/parity gates, then inspect a new real Actions run. Do not claim the workflow has been modernized until that run proves it.

References:
- https://github.blog/changelog/2026-09-23-node-20-is-no-longer-available-in-github-actions/
- https://github.com/actions/checkout/releases
- https://github.com/actions/setup-dotnet/releases
- https://github.com/actions/upload-artifact/releases
- https://github.com/actions/download-artifact/releases

### P1 — Assess .NET 10 migration before expanding the C# port

The inspected C# projects and CI lane targeted `net9.0`/.NET 9. Microsoft’s support policy listed November 10, 2026, as .NET 9 end of support and .NET 10 LTS support through November 2028. Check the current official policy, then plan/execute a tested migration of the spike, core, tests, fake-engine project, and CI SDK selection while the port is small. Keep this change reviewable and preserve CLI-parity proof.

Reference: https://learn.microsoft.com/dotnet/core/releases-and-support

### P2 — Verify the packaged Windows artifact, not only its manifest

The workflow already builds Qt on Windows, runs supported offscreen tests, deploys dependencies, and checks the staged portable package. The negative-test fixture for package construction does not prove that the real staged package has every runtime DLL/plugin or launches without developer tools.

First inspect the actual current jobs and artifact layout. If no suitable post-package runtime smoke test exists, add a focused job that downloads the exact Windows artifact into a fresh runner and:

1. Uses the staged package, not the build-tree executable.
2. Verifies required files and Qt plugin paths.
3. Runs the packaged CLI/engine on generated GIF fixtures.
4. Attempts a GUI launch in the supported offscreen mode where meaningful.
5. Produces diagnostics that identify missing DLLs/plugins or failed outputs.

This improves package confidence, but does not replace a genuinely clean consumer-machine test or real desktop input/dialog testing.

### P3 — Keep manual acceptance checks honest

The inspected project status marked two owner-side checks open:

- **W-18:** run the actual portable artifact on a Windows machine without Qt, MinGW, or development tools.
- **W-19:** test real-desktop GUI behavior that offscreen tests cannot fully establish.

Review the current issue/status files before relying on these IDs. Keep them open until the required real-world evidence is recorded.

Run-sheet: [docs/ci/WINDOWS_TEST_RUNSHEET.md](https://github.com/freeforall1932-design/gifscythe/blob/main/docs/ci/WINDOWS_TEST_RUNSHEET.md)

## 4. C# port scope and sequence

The intended direction is Windows-first C#/WPF. Preserve the working behavior and contracts that matter, adapt them to Gifscythe’s target architecture, remove features that the owner does not want only after tracing dependencies, and add requested capabilities. Do not mechanically translate all C++/Qt files or copy the existing Qt GUI layout as the default WPF design.

During the inspected snapshot, `csharp/Gifscythe.Core/` contained `Settings.cs`, `CommandBuilder.cs`, `SettingsWriter.cs`, and `ExitCodes.cs`. The core test project had unit tests and a CLI-parity lane comparing C# argument construction with the actual C++ CLI. Verify the current state before relying on this inventory.

The then-documented missing native-logic ports were:

- `Validate.h`
- `OutputPlan.h`
- `OutputName.h`
- `ProcessRunner.h`
- `ExplodeVerify.h`
- the configuration reader
- integration of the shell’s process/error behavior with the shared exit-code contract

Suggested sequence, subject to the current `WORKLIST.md`/`STATUS.md`:

1. Stabilize current CI/action runtime and decide the .NET 10 migration.
2. Port validation and output planning with boundary tests and parity against C++ behavior.
3. Port naming/path handling and configuration reading; test Windows path rules, Unicode, quoting, collisions, and settings round-trips.
4. Port process execution and explode/verify behavior; test timeouts, process-tree termination, bounded output, cancellation, invalid/missing output, and preservation of previous good output.
5. Resolve the exit-code contract consistently across the spike, core, tests, and docs.
6. Decide unresolved result/status contracts explicitly before treating a proposal as approved.
7. Build the WPF shell after the useful core contracts are tested and the visual direction is reviewed.
8. Package the intended Windows deliverable and test the staged artifact.

The inspected docs marked **U-91** (spike use of the shared exit-code contract) and **W-32** (per-file result/status contract) as open. Recheck current state. `docs/planning/W32_RESULT_CONTRACT.md` was explicitly a proposal, not an approved specification.

## 5. UI must be researched and visually reviewed

The owner has said text-only attempts leave agents guessing and that the new UI must not stubbornly reuse the same layout. This is a firm process constraint for the C# port.

- Research and inspect actual visual references; do not infer appearance solely from README prose.
- Use screenshots and a vision-capable tool when available; be honest if a reference could not be visually inspected.
- Create a feature map of **keep / adapt / drop / owner decision** separately from the visual hierarchy.
- Treat any XnConvert-inspired Input/Actions/Output/Status concept in repository docs as a functional reference to review, not permission to copy XnConvert’s visual design verbatim.
- If design intent remains open, create two or three genuinely different inexpensive mockups and explicitly show the previews before implementing the full WPF UI.
- Preserve the engine/domain behavior while independently designing layout, navigation, controls, and UI state.
- Verify empty/running/completed/partial-failure/error/cancelled states, keyboard use, window resizing, high-DPI behavior, and truthful progress/status.

Review [docs/planning/OWNER_DECISIONS.md](https://github.com/freeforall1932-design/gifscythe/blob/main/docs/planning/OWNER_DECISIONS.md) for current decisions, including any outstanding design/asset questions. Do not mark a decision resolved without evidence of owner approval.

## 6. Exact Arena continuation prompt

> Read `UNIVERSAL_AGENT_CONTEXT_v2.md` first, then this Gifscythe overlay. Verify the live branch, working tree, workflow mirror, current build configuration, open tasks, and most recent Actions run. Do not treat historical runs as proof of current health.
>
> Start by checking/updating GitHub Actions that still depend on the retired Node 20 runtime. Keep `.github/workflows/build.yml` and `docs/ci/build.yml.proposed` synchronized and byte-identical, run all relevant gates, and verify a new real Actions run. Next, assess a careful .NET 10 migration with current unit and C++ CLI-parity tests. Then inspect whether the real staged Windows artifact gets executed after packaging; add only a focused package-smoke job if this is a confirmed gap.
>
> For the C# port, use existing C++ implementation/tests as behavioral evidence where appropriate. Continue the currently missing core logic after verifying the latest worklist. Preserve the intended contracts and resolve owner decisions explicitly. Do not build the WPF shell by guessing or copying the current Qt UI. Research real visual references, inspect screenshots, create distinct preview mockups, and show them for review before committing to a substantially new interface.
>
> Report exact changed files, tests/commands actually executed, CI run IDs and outcomes, package/artifact verification, the visual references/previews inspected, and remaining owner/manual checks. Do not claim completion without evidence.

## 7. End-of-session report format

```text
Current branch/base commit:
Files inspected and changed:
Current CI run(s) and URLs/IDs:
Actions/toolchain/SDK versions:
Tests actually executed and outcomes:
Artifact package and checks performed:
.NET/core port status:
Visual references and previews actually reviewed:
Owner/manual checks still open:
Known limitations:
Next recommended action:
```

**No changes to the repository are implied by this context document.** Treat it as instructions for the next Arena session and re-verify the repository before acting.
