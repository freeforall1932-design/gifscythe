# Node 24 GitHub Actions runtime patch

## Target revision

This patch is based on `freeforall1932-design/gifscythe` `main` at:

`3dc49ce24838b636d6e4058ec7ad0a524108ee88`

Base blob SHA for both workflow files: `d22de8aec9e514445409fcba36592f8d9a692ad7`.
The two workflow copies were byte-identical at that revision.

## What it changes

It updates action major versions in both `.github/workflows/build.yml` and `docs/ci/build.yml.proposed`:

- `actions/checkout@v4` -> `actions/checkout@v7`
- `actions/setup-dotnet@v4` -> `actions/setup-dotnet@v6`
- `actions/upload-artifact@v4` -> `actions/upload-artifact@v7`
- `actions/download-artifact@v4` -> `actions/download-artifact@v8`

At preparation time, the corresponding action metadata declares the Node 24 runtime. The patch deliberately does **not** migrate the .NET SDK/TFMs from .NET 9 to .NET 10; that should be a separate change with its own build and parity proof.

The patch preserves the workflow structure and changes only the action references. It does not change `main` or create a branch/PR, and it has not been run on GitHub Actions because the connected GitHub integration refused branch creation with HTTP 403.

## Apply

Start from the exact base revision to avoid applying this against a moved workflow:

```bash
git fetch origin main
git switch --detach 3dc49ce24838b636d6e4058ec7ad0a524108ee88
git switch -c fix/node24-actions-runtime
git apply --check node24-actions-runtime.patch
git apply node24-actions-runtime.patch
```

If you already have a local checkout, save this patch at the repository root as `node24-actions-runtime.patch` or pass its full path to `git apply`.

## Local verification

Run from the repository root after applying:

```bash
node working_code/gifscythe/scripts/lint_workflow.mjs .github/workflows/build.yml
node working_code/gifscythe/scripts/lint_workflow.mjs --selftest
./working_code/gifscythe/scripts/check_docs.sh --no-gate-run
cmp .github/workflows/build.yml docs/ci/build.yml.proposed
```

The `check_docs.sh` gate may run project-specific checks or require dependencies, so record actual outcomes rather than treating missing tooling as a pass. Then push the branch and inspect the resulting GitHub Actions run, including all active jobs and any failed-job logs. Do not merge solely because the patch applies or the YAML linter passes.

## Expected diff

Across the two files, 22 action-reference occurrences change in total: 12 checkout references, 2 setup-dotnet references, 4 upload-artifact references, and 4 download-artifact references.
