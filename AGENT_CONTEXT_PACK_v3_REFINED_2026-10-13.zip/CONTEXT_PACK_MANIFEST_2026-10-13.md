# Context pack manifest (2026-10-13)

Authoritative files:
- `UNIVERSAL_AGENT_CONTEXT_v3.md`: reusable, project-agnostic instructions.
- `GIFSCYTHE_PROJECT_OVERLAY_v3.md`: project-only facts, current status and next actions.
- `SESSION_HANDOFF_UNIVERSAL_CONTEXT_AND_PROJECT_2026-10-13.md`: current launcher and task handoff.
- `UNIVERSAL_CONTEXT_V3_REFINEMENT_NOTES_2026-10-13.md`: project-agnostic record of refinements.

Reference/history only:
- `OPTIONAL_RESEARCH_TOOL_REFERENCES.md`: optional niche research catalog.
- `arena_github_ci_qt6_transfer_context.md`: original setup context; historical.
- `SESSION_HANDOFF_UNIVERSAL_CONTEXT_AND_GIFSCYTHE_2026-10-12.md`: prior handoff; superseded by the 2026-10-13 handoff for current status.
- `GIFSCYTHE_PROJECT_OVERLAY_v2.md`: historical overlay, superseded by v3.

The universal guide contains no named project, project URL, project task ID, or project-specific runtime version. Project-specific implementation findings remain in the overlay and handoff.
