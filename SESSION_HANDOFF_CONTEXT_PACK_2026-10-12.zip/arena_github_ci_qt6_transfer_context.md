# Transferable Project Context: Arena Agent + GitHub Actions for Heavy Builds

**Document type:** Reusable context / project brief for another AI session  
**Last reviewed:** 2026-10-12  
**Primary environment:** Arena Agent Mode + GitHub repository + GitHub Actions  
**Main goal:** Move dependency installation, compilation, testing, and packaging onto GitHub-hosted runners so Arena can focus on code changes and diagnose real CI results.

## 1. What I am trying to achieve

I want to use [Arena Agent](https://arena.ai/agent) to develop an application while making GitHub do as much of the repetitive and resource-intensive engineering work as practical.

The workload I have in mind includes Qt 6, CMake, C/C++ compilation, large dependency installation, automated tests, and building downloadable outputs. I do not want to rely on a complete Qt development environment being installed on my local computer or available inside Arena's sandbox.

The intended feedback loop is:

1. Arena inspects the actual repository and edits code or build configuration.
2. Arena commits changes to a working branch or opens a pull request using its GitHub integration.
3. GitHub Actions runs a clean, reproducible build on a GitHub-hosted runner.
4. The workflow runs available tests and packages the actual deliverable where practical.
5. GitHub stores build outputs as downloadable workflow artifacts.
6. Arena inspects failures from the real Actions logs, fixes them, and reruns CI.
7. I review the diff, logs, and artifact before accepting the changes.

The goal is a dependable build-and-test loop, not merely generating a workflow file that looks plausible.

## 2. Important existing project context

A related project discussed previously is a **WebAssembly animated-media converter**, envisioned as an offline, XnConvert-like tool for animated image formats such as GIF, WebP, and APNG. Prior desired capabilities included batch processing, frame-level editing, frame-rate controls, and compression controls. Technologies discussed included FFmpeg, Gifski/ImageMagick, libwebp, and apngasm, with an interest in WebAssembly.

**Do not assume this current repository is that project or that it should use Qt.** Inspect the repository first. If the application is browser-based JavaScript/WebAssembly, CI should build its actual web stack and produce the relevant web bundle. A Qt 6 workflow is appropriate only if the source code really uses Qt. If this is a separate Qt/CMake project, follow that project's existing architecture instead of forcing it into the animated-media converter stack.

## 3. Core division of responsibilities

| Component | Responsibility |
|---|---|
| Arena Agent | Understand the repository, edit source/CMake/tests/workflows, inspect diffs, interpret CI logs, fix failures, document the result. |
| GitHub repository | Source-of-truth for code, commits, branches, pull requests, workflow definitions, and CI status. |
| GitHub Actions | Provision a clean runner, install required dependencies, configure, compile, run tests, package outputs, and upload artifacts. |
| GitHub Actions artifacts | Store temporary downloadable build products and test reports associated with a workflow run. They are not automatically permanent releases. |
| Local machine | Review code and download/test artifacts; a full local Qt build toolchain should not be a prerequisite for the remote CI loop. |

GitHub Actions does not magically repair build errors, and a successful Linux build does not prove a Windows, macOS, Android, or WebAssembly build works. It is a remote, reproducible build environment whose commands and dependencies must match the project.

## 4. Preferred approach

Start with **ordinary GitHub Actions workflow YAML**, not a collection of agent plugins.

Minimum viable setup:

- Arena's built-in GitHub connection and repository access.
- One project-specific workflow in `.github/workflows/`.
- A pinned or deliberately selected runner OS, compiler/build tools, and dependency versions.
- CMake configure and build commands matching the repository.
- `ctest --output-on-failure` only if the project has tests configured; otherwise clearly report that no tests were run.
- Artifact upload for the actual distributable output, if packaging is configured.
- Concurrency cancellation, a reasonable timeout, minimal permissions, and caching only where it has a measurable benefit.

Do not add `gh-aw`, APM, OpenClaw, or third-party workflow skills as prerequisites. They may be evaluated later if a specific need appears, but they do not compile C++ by themselves.

## 5. Repository inspection required before implementation

Before writing a workflow, the agent must determine:

- Is this repository actually a Qt 6/CMake project, a web/WebAssembly project, or a mixed project?
- Where is the top-level `CMakeLists.txt`, `package.json`, CMake preset, or other real build entry point?
- Which Qt modules are used (`Core`, `Gui`, `Widgets`, `Qml`, `Quick`, `Multimedia`, `WebEngine`, etc.)?
- Is the required Qt version specified in the source, presets, documentation, or lock/configuration files?
- Which compiler, C++ standard, CMake version, and generator are required?
- Which external libraries or system packages are required?
- Does the repository already have tests and how are they invoked?
- What platforms are actual targets: Linux, Windows, macOS, Android, or WebAssembly?
- What output files/directories are really generated, and what must be packaged for users to run the application?
- Are any workflows already present that must be preserved or improved rather than replaced?

The agent should not invent module names, replace the build system without cause, assume a generic `build/` or `dist/` output path, or claim that packaging is complete without verifying the produced files.

## 6. Build-target decision guide

### A. Qt 6 desktop application

- Use the operating system and compiler required by the real target.
- A Linux build can be a convenient first CI job if the project supports Linux.
- Ubuntu packages such as `qt6-base-dev` can work for a simple app if their Qt version and modules match the project.
- For a specific Qt SDK/version, the community action [`jurplel/install-qt-action`](https://github.com/jurplel/install-qt-action) can install Qt on GitHub Actions. Select its host, version, target, architecture, and modules based on the project's requirements rather than blindly using defaults.
- Use CMake's actual project configuration. Qt must be installed or otherwise made available to CMake; it is not generally appropriate to FetchContent-build Qt itself as a routine dependency.
- A compiled executable may not be a portable distribution. Include the required Qt runtime libraries, plugins, assets, and platform dependencies through the project's appropriate deployment/packaging method.

### B. WebAssembly application

- Use the repository's actual web toolchain and package manager, if it is a browser app rather than a Qt app.
- For a Qt WebAssembly target, configure a compatible Qt WebAssembly SDK and Emscripten toolchain. Cross-compilation needs the matching toolchain file, not just a generic desktop Qt path.
- Upload the complete web bundle needed for deployment, not just a single `.wasm` file. This can include JavaScript glue code, HTML, data files, workers, and other runtime assets depending on the project.
- Validate that the deliverable runs under the intended local/offline hosting model if that is a project requirement. A successful compile alone does not prove browser runtime behavior or offline operation.

### C. Multiple platforms

Do not start with a large build matrix unless those targets are required. Get one representative target compiling first, then add Windows/macOS/Android/WebAssembly jobs based on genuine requirements. Each platform requires its own appropriate compiler, SDK, dependencies, and packaging steps.

## 7. Workflow quality requirements

Every workflow produced for this project should:

1. Run on a clean GitHub-hosted runner and avoid hidden state from Arena's sandbox or the developer's machine.
2. Use least-privilege permissions, normally beginning with `contents: read` for a build-only workflow.
3. Avoid exposing secrets to untrusted pull-request code. Do not introduce `pull_request_target` or broad write permissions without a clearly justified, reviewed design.
4. Use a stable runner label appropriate to the project. As of the review date, `ubuntu-24.04` is a reasonable explicit baseline for Linux; verify runner availability and lifecycle before relying on a label long term.
5. Include a reasonable job timeout and concurrency handling to cancel obsolete runs where appropriate.
6. Use a dependency/toolchain cache only where cache keys and invalidation can be designed correctly. Caching is an optimization, not a substitute for reproducible dependency setup.
7. Use actual project configure/build/test commands and fail honestly when any step fails.
8. Preserve test failure output and avoid disabling tests, swallowing errors, or changing the workflow to report a false success.
9. Upload only intentional outputs, such as packaged application files, test reports, or diagnostic logs. Avoid uploading the entire build tree by default.
10. Label artifacts by target OS/architecture/configuration when more than one artifact exists.
11. Review workflow action versions and security guidance before committing. Confirm current action releases rather than assuming versions from this document remain current.
12. Explain what was built, which tests ran, where artifacts can be downloaded, what remains unverified, and which steps failed or were blocked.

## 8. Artifact requirements

The workflow should upload the **actual deliverable** after the project's real packaging step. Examples include:

- A desktop release archive or installer with required runtime dependencies.
- A complete browser/WebAssembly deployment bundle.
- Test reports or useful diagnostics when relevant.

Use the real output path discovered from the repository. Do not assume that Qt executables or web builds are always placed in `dist/`.

GitHub Actions artifacts are run-associated downloads and have retention limits. If a permanent user-facing release is required, treat GitHub Releases or another hosting/deployment target as a separate task with appropriate permissions and approval gates.

## 9. Reusable prompt for Arena Agent

Copy this prompt into Arena Agent after connecting the correct GitHub repository:

> Inspect this repository and implement a reproducible GitHub Actions CI workflow that moves dependency installation, compilation, automated testing, and packaging off my local machine and Arena sandbox and onto GitHub-hosted runners.
>
> First identify the actual application stack and build system. Determine whether this is really a Qt 6/CMake project or a web/WebAssembly project. Do not force Qt into a project that does not use it. Inspect the existing build files, dependency requirements, tests, target platforms, and generated output paths before changing anything.
>
> Start with one appropriate target platform and one simple working workflow. Install the project's required prebuilt SDKs and dependencies rather than building Qt from source unless there is a demonstrated requirement. Use the project's real configure, compile, test, and packaging steps. Add platform-specific builds only when justified by the repository's intended targets.
>
> Use least-privilege workflow permissions, safe handling of pull requests and secrets, reasonable timeouts, concurrency cancellation where appropriate, and caching only where correct and useful. Do not suppress errors, remove meaningful tests, or claim success unless GitHub Actions actually reports a successful run.
>
> Upload the real distributable output as a named, downloadable workflow artifact, if the project can produce one. Include necessary runtime files. Do not guess output paths or upload the entire build tree by default. If the app is WebAssembly, package the complete web bundle. If it is a desktop Qt app, package the required Qt runtime dependencies for the target OS.
>
> Create the workflow and any minimal supporting documentation, review the diff, and prepare changes on a branch or pull request. After a real Actions run, read its logs and fix actual failures. In the final report, state the exact target platform, Qt/toolchain versions, configure/build/test/package commands, CI result, artifact location, and all limitations or remaining manual steps. If a required repository detail is missing, make the best supported progress and document the blocker rather than inventing a value.

## 10. Staged implementation plan

### Stage 1: Connect and inspect

- Connect GitHub in Arena Agent Mode and grant access only to the intended repository.
- Enable GitHub for the Agent Mode session.
- Ask Arena to inspect and summarize the existing build before editing.
- Have Arena identify the smallest valid CI target and existing tests.

### Stage 2: First passing CI build

- Add one workflow.
- Install the correct toolchain and dependencies.
- Configure and build the project.
- Run tests if present.
- Correct failures using the Actions logs.

### Stage 3: Obtain a useful artifact

- Identify the actual packaging mechanism.
- Upload the intended output as an Actions artifact.
- Download and verify the artifact. Where practical, test it in a clean environment matching the target.

### Stage 4: Optimize

- Review build duration and bottlenecks.
- Add cache keys for expensive stable dependencies or compiler outputs where supported.
- Use concurrency cancellation, paths filters, and reduced matrix jobs only when they preserve correct behavior.
- Consider a workflow-optimization skill or agentic workflow only if the repository has enough recurring CI maintenance to justify it.

### Stage 5: Expand targets, if needed

- Add separate platform jobs for targets the application actually supports.
- Keep artifacts clearly labeled by OS and architecture.
- Add release publishing or deployment only after basic CI and artifacts are reliable.

## 11. Original tool list: current decision

| Tool/project | Current decision | Reason |
|---|---|---|
| Standard GitHub Actions | Use now | Directly performs remote builds, tests, and artifact uploads. |
| Arena GitHub integration | Use now | Lets Arena work with the repository, branch, pull request, and CI checks. |
| `jurplel/install-qt-action` | Evaluate for actual Qt targets | Can install a selected Qt SDK and related modules; not needed for a non-Qt web project. |
| SkillMedev `github-actions` skill | Optional | Could help author workflow files, but isn't required to begin. Verify its current status and source before installing. |
| `optimize-runner-usage` | Later, if needed | Optimization is premature until the baseline workflow exists and can be measured. Verify current repository, command, adoption, and compatibility before use. |
| GitHub Agentic Workflows (`gh-aw`) | Defer | For AI-assisted repository automation, not a prerequisite for compiling Qt/CMake. |
| OpenClaw-related GitHub skills | Skip initially | Introduces another agent framework and credential/configuration work without being required for CI. |
| Microsoft APM | Defer | More relevant when maintaining reusable agent skills/prompts across supported environments. Not a compiler/build service. |

## 12. Constraints and open decisions for future refinement

Keep these items open until the actual repository has been inspected:

- Repository URL and current branch.
- Whether the project really uses Qt 6, CMake, web technologies, or a mixture.
- Exact Qt version and required modules, if applicable.
- Primary target OS and architecture.
- Whether the app should be a desktop executable, installer/archive, WebAssembly bundle, or another deliverable.
- Whether tests already exist, and whether browser/UI/runtime smoke tests are needed.
- Whether the repository is public or private and what GitHub Actions minutes/artifact retention constraints apply.
- Whether releases should be published automatically or only stored as workflow artifacts.
- Whether large native dependencies should be built from source, fetched as prebuilt binaries, or cached from source builds. Do this only after identifying the real dependencies and licensing constraints.

## 13. Sources checked for this version

These links were reviewed on **2026-10-12**. Recheck current documentation before implementing because product UIs, action versions, runner images, and SDK releases can change.

- Arena Agent Mode repository workflow: https://help.arena.ai/articles/1655691990-how-to-use-coding-in-agent-mode
- Arena Agent Mode overview and file handling: https://help.arena.ai/articles/5432423882-how-to-use-agent-mode
- Qt 6: Making Qt available in CMake projects: https://doc.qt.io/qt-6/cmake-making-qt-available.html
- Qt 6: Getting started with CMake: https://doc.qt.io/qt-6/cmake-get-started.html
- `install-qt-action` usage and available options: https://github.com/jurplel/install-qt-action
- GitHub Actions runner images: https://github.com/actions/runner-images
- GitHub-hosted runner selection: https://docs.github.com/en/actions/how-tos/write-workflows/choose-where-workflows-run/choose-the-runner-for-a-job
- `actions/checkout` releases: https://github.com/actions/checkout/releases
- `actions/upload-artifact` releases: https://github.com/actions/upload-artifact/releases
- GitHub Agentic Workflows: https://github.com/github/gh-aw
- Microsoft APM: https://microsoft.github.io/apm/

## 14. Key principle

**Make the real repository build successfully on a clean GitHub runner first. Then make the artifact useful. Only then optimize or add agent frameworks.**
