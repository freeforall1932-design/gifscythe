# Session Handoff — Universal Agent Context + Gifscythe CI/C# Port

**Prepared:** 2026-10-12  
**Purpose:** Start a fresh ChatGPT conversation without losing the discussion, decisions, created files, research direction, or remaining work from the previous chat.

> **Important:** The universal context is still an evolving document. Treat v3 as the latest working version, not as permanently finalized. Keep improving it when a genuine general-purpose gap appears, but do not make it bloated with assumptions that only fit Gifscythe.

---

## 1. What this conversation was about

The user asked to continue from an uploaded Markdown handoff about using Arena Agent Mode + GitHub Actions for tasks too heavy for an agent sandbox. The main concrete repository is:

- **Gifscythe:** https://github.com/freeforall1932-design/gifscythe
- Original context supplied at session start: `arena_github_ci_qt6_transfer_context.md`

The user’s immediate concern was that Arena lacks a dependable local Qt 6/CMake/CLI environment, so the coding agent cannot independently compile/test everything in its sandbox. The broader concern then expanded: the user is considering porting Gifscythe’s useful working logic into C# and a new UI, but text-only instructions repeatedly cause agents to guess how the interface should look or stubbornly reuse the same design.

The user asked for a universal Markdown context that works for **any repository**, with reusable instructions for remote CI, coding, testing, tool research, cross-language ports, reference inspection, and UI design—rather than a file that assumes every project is Qt, C#, a desktop app, or game-modding software.

The user then explicitly added an important requirement: when no saved repository/reference fits a project, the agent must research the current ecosystem for similar or adjacent implementations, using code-hosting sites, forums, issue trackers, and public social discussion. The research should be ranked from highest to lower fit after examining evidence, not limited to the user’s bookmarked repositories.

## 2. User preferences and constraints to preserve

The next assistant/agent must remember these instructions:

1. **Read the query carefully and follow the actual request.** Do not rigidly repeat the old approach, architecture, or UI merely because it is already present.
2. **Use evidence, not guesswork.** Inspect source, tests, logs, documentation, real screenshots, and actual project behavior. Clearly label unknowns and inferences.
3. **Research when needed.** Use current web research for niche tools, libraries, project candidates, platform-specific builds, and anything likely to have changed. Search original code hosts (GitHub, GitLab and relevant alternatives), project issue trackers/releases, forums, Reddit, Hacker News, and public social/community sources when accessible and useful.
4. **Rank recommendations.** When presenting repositories/tools, rank high to low fit, and explain the criteria. Stars or popularity alone do not prove quality. Check maintenance, actual code, tests, platforms, language, integration cost, license, security model, and evidence from community discussions.
5. **Search for similar work, not just identical names.** Look for the same purpose and neighboring architecture—for example: GUI wrapping a CLI engine; a web UI invoking a local process; a cross-platform front end over a shared core; desktop packaging of native dependencies; a service/CLI rewrapped with GUI; offline browser apps; or equivalent workflows in another language or OS.
6. **Visual UI work must use visual evidence.** When relevant, inspect actual screenshots/application screens with image/vision-capable tools. Do not claim to have viewed an image if only text was read. If the direction is unclear, create two or three meaningfully different small mockups and explicitly show previews for review before building the full UI.
7. **Separate logic from presentation.** Preserve and test useful existing behavior, adapt integration and architecture for the target project, and design the UI separately. Make explicit keep/adapt/drop/owner-decision lists. Do not blindly translate or clone every original file.
8. **Use Arena when repository integration is already available.** A separate coding agent/IDE is optional, not a prerequisite. Use GitHub Actions for SDKs/compilers/platforms missing from Arena. Do not claim a build or run succeeded unless it actually did.
9. **Improve existing automation before adding more.** Inspect current CI and artifacts first. Add only jobs that cover real gaps. Do not create duplicate workflows or force extra tools into every project.
10. **Be direct and honest.** No fake successful tests, guessed output paths, invented repository capabilities, or silent assumptions. Report what was verified and what remains unverified.

## 3. Files created during this conversation

These exact files were created in `/mnt/data` and were checked to exist at the time of handoff.

### Current universal context — use this for any repository

**`UNIVERSAL_AGENT_CONTEXT_v3.md`**  
[Download the universal context v3](sandbox:/mnt/data/UNIVERSAL_AGENT_CONTEXT_v3.md)

This is the latest iteration of the universal instructions. It covers:

- carefully parsing user requirements, constraints, exclusions, and open decisions;
- repository reconnaissance before edits;
- Arena versus GitHub Actions responsibilities;
- general CI/build/test/package strategy for arbitrary stacks;
- honest verification levels and artifact testing;
- porting logic across languages without blindly copying UI;
- mandatory visual research and mockup review for UI work;
- **mandatory ecosystem research when the existing references do not fit**, with broad code-hosting/community research and ranked candidates;
- keeping changes focused and preserving unresolved owner decisions;
- a reusable prompt and end-of-task report format.

**The universal context is still open to improvement.** Continue refining it if the new session identifies a truly general gap. Keep project-only details and niche tool catalogs out of the universal file unless they represent a broadly reusable method.

### Gifscythe-specific overlay

**`GIFSCYTHE_PROJECT_OVERLAY_v2.md`**  
[Download the Gifscythe overlay](sandbox:/mnt/data/GIFSCYTHE_PROJECT_OVERLAY_v2.md)

This is project-specific, not the universal default. It records the inspected CI structure, the suggested priorities, C# port scope, UI-review requirements, and a continuation prompt. It must be revalidated against the latest repository branch before action.

### Optional saved research-tool references

**`OPTIONAL_RESEARCH_TOOL_REFERENCES.md`**  
[Download optional tool references](sandbox:/mnt/data/OPTIONAL_RESEARCH_TOOL_REFERENCES.md)

This preserves the user’s nine saved repositories without making them mandatory dependencies:

1. https://github.com/HexRaysSA/ida-mcp
2. https://github.com/bethington/ghidra-mcp
3. https://github.com/trevaintdead/ai-game-modding-guides
4. https://github.com/morluto/rea
5. https://github.com/rehan-remade/universal-modder
6. https://github.com/ymatrix1/PortPS5
7. https://github.com/boykopovar/AnyPS5
8. https://github.com/SamboyCoding/Cpp2IL
9. https://github.com/icsharpcode/ILSpy

These are leads only. Select them only if the project genuinely requires reverse engineering, .NET assembly inspection, Unity IL2CPP research, or game-modding capabilities. The universal agent should research suitable alternatives when these do not fit the target task.

### ZIP pack for context transfer

**`AGENT_CONTEXT_PACK_v3.zip`**  
[Download the existing context pack v3](sandbox:/mnt/data/AGENT_CONTEXT_PACK_v3.zip)

This is the previously created pack of v3 universal context plus Gifscythe overlay and optional tool-reference document. It does **not** yet include this new session handoff file, which was created afterward. A separate bundle including this handoff can be generated if needed.

### Earlier drafts / historical inputs

- `UNIVERSAL_AGENT_CONTEXT_v2.md` — earlier iteration, superseded by v3.
- `UNIVERSAL_AGENT_CI_AND_REFERENCE_DRIVEN_PORTING.md` — original generalized draft, superseded by v3.
- `GIFSCYTHE_CURRENT_REVIEW_AND_CONTINUATION_CONTEXT_2026-10-12.md` — an earlier project-specific handoff draft; useful for historical details, but use the newer overlay and re-check current repository state.
- `arena_github_ci_qt6_transfer_context.md` — original input handoff supplied at the beginning of this conversation; historical baseline for the initial remote-CI problem.

## 4. Gifscythe: known context from the repository review

Repository: https://github.com/freeforall1932-design/gifscythe

The work here was an inspection of repository files and current docs. **No repository source/workflow files were modified in this conversation, and no new GitHub Actions run was triggered.** Recheck the branch, latest commit, current workflow and current CI status before treating any item below as still true.

### Existing remote build infrastructure

The inspected `.github/workflows/build.yml` already had Qt 6 / CMake-related build and testing jobs rather than an empty CI setup. The workflow included a Linux lane, a Windows lane that installed Qt 6.7.3 + MinGW and built through CMake/Ninja, offscreen GUI tests, portable packaging/manifest checks, plus portability and C# spike/core lanes. The project documentation also stated that the workflow must mirror `docs/ci/build.yml.proposed` byte-for-byte.

The Qt-free local native build entry point is documented as:

```bash
cd working_code/gifscythe
./build.sh
```

The full Qt build is requested with:

```bash
./build.sh --all
```

A local fallback script exists at `working_code/gifscythe/scripts/build_qt6_local.sh`; it builds a Qt 6.8.3 subset from source for the special case where local reproduction is useful. It is not a prerequisite for all work. Its opening usage example appeared to reference an older/wrong build path; the script’s own final printed commands should be preferred pending a verified fix.

### CI maintenance concern

At the time of the review, `.github/workflows/build.yml` and its mirror used:

- `actions/checkout@v4`
- `actions/setup-dotnet@v4`
- `actions/upload-artifact@v4`
- `actions/download-artifact@v4`

Those versions’ action metadata used Node 20. GitHub announced the Node 20 retirement date as **2026-09-23**. This was identified as a priority maintenance task: verify current releases/runtime compatibility, update live workflow and byte-identical mirror together, then execute and inspect a new real Actions run. Candidate major versions noted at the time were checkout v7, setup-dotnet v6, upload-artifact v7 and download-artifact v8; do not paste those blindly—verify current release versions and compatibility immediately before changing the repo.

Relevant source links:

- https://github.blog/changelog/2026-09-23-node-20-is-no-longer-available-in-github-actions/
- https://github.com/actions/checkout/releases
- https://github.com/actions/setup-dotnet/releases
- https://github.com/actions/upload-artifact/releases
- https://github.com/actions/download-artifact/releases

### Package verification gap to assess

The existing Windows job compiled and tested the Qt GUI, then staged the portable package and asserted expected files in a manifest. The review proposed checking whether the **actual staged deliverable** is ever launched/tested on a separate clean runner. If not, add only a focused package-smoke job that downloads that exact run’s artifact, runs the staged executable/CLI against fixtures, checks relevant runtime/plugin/dependency behavior, and emits useful logs.

Do not add another broad Qt build workflow: first inspect what the current one proves. Packaged-artifact CI still does not replace the project’s owner/manual real-desktop tests.

### Manual Windows tests explicitly left open in the inspected docs

- **W-18:** run the actual portable artifact on a Windows machine without Qt, MinGW, or development tools.
- **W-19:** visible real-desktop GUI probes for behavior offscreen CI cannot fully prove (for example physical drag/drop or interacting with desktop dialogs).

The run sheet was `docs/ci/WINDOWS_TEST_RUNSHEET.md`. Recheck current status; do not close these based only on a green CI job.

### C# port direction and remaining scope

User is considering a Windows-first C#/WPF product port, preserving useful logic from the working codebase but adapting it to the user’s own architecture, removing unwanted features, and adding what the user explicitly asks for. UI design must not be guessed from a textual description or mechanically copy the Qt UI layout.

The inspected C# Core was `csharp/Gifscythe.Core/` (then `net9.0`) containing `Settings.cs`, `CommandBuilder.cs`, `SettingsWriter.cs`, and `ExitCodes.cs`, with a core test project and CLI-parity lane comparing the C# argument builder against the C++ CLI. The then-documented missing logic ports included:

- `Validate.h`
- `OutputPlan.h`
- `OutputName.h`
- `ProcessRunner.h`
- `ExplodeVerify.h`
- the configuration reader
- integration of process/error handling with the shared exit-code contract

The inspected notes identified **U-91** as an open shared exit-code contract task and **W-32** as an open per-file results/status model. `docs/planning/W32_RESULT_CONTRACT.md` was marked proposed, not approved. Recheck all of this against current `STATUS.md`, `WORKLIST.md`, and current source before planning changes.

The discussion also recommended considering .NET 10 LTS before the C# port grows because .NET 9 support was documented as ending on November 10, 2026. Validate current Microsoft policy and run the tests when performing the upgrade.

### UI research requirement

Before building the WPF shell:

1. research and inspect actual reference applications/screenshots/source, not only textual descriptions;
2. distinguish observed requirements from guesses;
3. create keep/adapt/drop/owner-decision mapping for features;
4. create two or three genuinely different mockups when direction is not pinned down and explicitly show previews;
5. obtain the user’s direction at a meaningful design checkpoint;
6. implement around tested C# logic and verify empty/running/success/partial-failure/error/cancel states, keyboard and window behavior.

An XnConvert-inspired Input/Actions/Output/Status idea in project notes is a feature/navigation reference to review, not permission to copy an existing product’s visual design verbatim.

## 5. Broader universal-context requirement added later in the conversation

The user asked whether the universal guide already covers projects that are not represented by their saved repository list, then explicitly requested the capability to:

- if none of the saved items match the project, research current projects that solve similar problems or are on a similar implementation path;
- consider both identical functionality and adjacent architecture;
- research source hosts such as GitHub, GitLab and other relevant public code hosts;
- also research forums, social/community discussions, issue threads and release activity;
- rank candidates from highest-fit to lower-fit, using more than popularity counts;
- inspect implementation language, actual architecture, how a tool interacts with a website, wraps/hosts a CLI engine, shares logic between UI and CLI, packages runtime dependencies, or supports Linux/Windows/macOS/Android/browser and other relevant targets;
- use this research to inform an implementation plan, while not blindly copying foreign code or adding every discovered tool.

This requirement was added in `UNIVERSAL_AGENT_CONTEXT_v3.md` under **“Mandatory ecosystem research when existing references do not fit.”** It is a key part of the ongoing universal context and must not be removed in future revisions. Universal research is triggered by meaningful architecture/porting/tooling decisions—not every trivial edit.

## 6. What research examples were discussed

The assistant gave examples of repositories that illustrate different use cases:

- REA: https://github.com/morluto/rea — broad app/binary investigation lead.
- ILSpy: https://github.com/icsharpcode/ILSpy — .NET assembly browser/decompiler.
- IDA MCP: https://github.com/HexRaysSA/ida-mcp — IDA automation for native binary analysis.
- Ghidra MCP: https://github.com/bethington/ghidra-mcp — Ghidra automation.
- Cpp2IL: https://github.com/SamboyCoding/Cpp2IL — Unity IL2CPP-specific analysis.
- Universal Modder: https://github.com/rehan-remade/universal-modder — AI-assisted game modding.
- AI Game Modding Guides: https://github.com/trevaintdead/ai-game-modding-guides — game-modding agent guides.
- PortPS5: https://github.com/ymatrix1/PortPS5 — specialized PS5 binary portability work.
- AnyPS5: https://github.com/boykopovar/AnyPS5 — specialized PS5 executable relinking/interoperability.

Later the assistant also cited examples of GUI/CLI or tool-wrapping projects: Tuw (`https://github.com/matyalatte/tuw`), pgn2scid (`https://github.com/CasualPyDev/pgn2scid`), and webos-devtool (`https://github.com/dvangennip/webos-devtool`). These examples are illustrations only. A fresh session should research current state, popularity/community evidence, license, maintenance, and technical match before recommending any project again.

## 7. Current artifact set and which one is authoritative

Use the following roles:

| File | Role | Guidance |
|---|---|---|
| `UNIVERSAL_AGENT_CONTEXT_v3.md` | Universal coding-agent instructions | Current working version; still open to revision. |
| `GIFSCYTHE_PROJECT_OVERLAY_v2.md` | Gifscythe-only facts and continuation steps | Revalidate all repository state before acting. |
| `OPTIONAL_RESEARCH_TOOL_REFERENCES.md` | The nine user-saved tools, optional only | Keep optional, not a mandatory stack. |
| `AGENT_CONTEXT_PACK_v3.zip` | ZIP of v3 + project overlay + optional references | Earlier ZIP; does not contain this handoff. |
| `UNIVERSAL_AGENT_CONTEXT_v2.md` | Earlier universal revision | Superseded by v3. |
| `UNIVERSAL_AGENT_CI_AND_REFERENCE_DRIVEN_PORTING.md` | First general context draft | Superseded by v3. |
| `GIFSCYTHE_CURRENT_REVIEW_AND_CONTINUATION_CONTEXT_2026-10-12.md` | Earlier project-specific handoff | Historical; prefer overlay v2 plus a fresh repo inspection. |
| `arena_github_ci_qt6_transfer_context.md` | Original context document supplied by user | Preserve as initial reference if useful. |
| `SESSION_HANDOFF_UNIVERSAL_CONTEXT_AND_GIFSCYTHE_2026-10-12.md` | This complete chat handoff | Use it to start the new conversation. |

## 8. Recommended first message in the fresh chat

Upload this handoff and `UNIVERSAL_AGENT_CONTEXT_v3.md`. If continuing Gifscythe, also upload `GIFSCYTHE_PROJECT_OVERLAY_v2.md` and optionally `OPTIONAL_RESEARCH_TOOL_REFERENCES.md`. Then send:

> Read the session handoff first; it summarizes the context and the files already created. Our universal context is still under development, and v3 is the latest working version—not final. Preserve the mandatory ecosystem research requirement: when the saved tools do not match the task, research comparable projects across code hosts, issue trackers, forums, and public community/social sources, inspect evidence, and rank candidate projects from highest to lower fit. Keep this universal logic stack-agnostic and keep Gifscythe-specific facts in its separate overlay. Before acting on Gifscythe, inspect the current repository branch, status, workflows and current CI runs because the previous conversation did not modify the repo or trigger a new run. Continue from the next concrete task and report actual evidence.

## 9. What has not happened

To avoid a false assumption in the new session:

- No Gifscythe repository code or workflow was changed in these context-writing steps.
- No GitHub Actions run was launched as part of this conversation.
- No actual WPF interface was implemented or accepted.
- No visual mockup has been approved by the user.
- The universal context was iterated from initial generic draft to v2 and v3; the user is still working on its quality and scope.
- The optional saved references have been cataloged but not installed as plugins/tools.
- Any current branch state, current green/red CI result, updated action releases, .NET support status, or candidate repository health must be re-verified in the fresh session.

## 10. Main continuation priority

There are two related but separate workstreams:

**A. Universal context quality:** keep improving `UNIVERSAL_AGENT_CONTEXT_v3.md` so it handles arbitrary repositories, general project research, architecture comparisons, logic porting, UI visual validation, build/test automation, and reliable evidence reporting. Do not let the Gifscythe overlay or the nine saved tools dominate the universal instructions. If another universal revision is made, update the related ZIP and keep the filenames/version labels consistent.

**B. Gifscythe development:** once the universal context is good enough, follow the overlay’s suggested order: check the current repo and current CI; validate/update GitHub Actions runtime versions and the workflow mirror; evaluate the .NET 10 migration; check/add a narrow package smoke test only if it fills a confirmed gap; then continue C# core logic and visual-reference-driven WPF planning. Keep owner/manual tests open until real evidence exists.

Do not conflate these workstreams. A better universal prompt is not a substitute for running CI, and a green Gifscythe build is not proof the universal guide is finished.
